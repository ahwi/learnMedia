# BXC_TcpServer_select
* 作者：北小菜
* 邮箱：bilibili_bxc@126.com
* QQ：1402990689
* 微信：bilibili_bxc
* 作者主页：http://www.any12345.com
* 作者-哔哩哔哩主页：https://space.bilibili.com/487906612
* 作者-头条西瓜主页：https://www.ixigua.com/home/4171970536803763


## 项目介绍
1. BXC_TcpServer_select 是《IO多路复用select/poll/epoll》第1讲，基于tcp+select实现的IO多路复用的服务端源码  [BiliBili视频教程地址](https://www.bilibili.com/video/BV1Fv4y167kj) 
2. BXC_TcpClient        是《IO多路复用select/poll/epoll》第1讲，基于tcp实现的客户端源码 [BiliBili视频教程地址](https://www.bilibili.com/video/BV1Fv4y167kj) 

### windows系统编译运行
~~~
visual studio 打开 BXC_TcpServer_select.sln （作者使用的是vs2019）

选择 x64/Debug 或 x64/Release都能够直接运行，没有任何第三方依赖库

~~~




