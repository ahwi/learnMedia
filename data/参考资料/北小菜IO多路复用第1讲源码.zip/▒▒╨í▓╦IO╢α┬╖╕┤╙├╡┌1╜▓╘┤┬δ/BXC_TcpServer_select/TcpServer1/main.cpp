#include <stdint.h>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iostream>
#pragma comment(lib, "ws2_32.lib")

//  __FILE__ ��ȡԴ�ļ������·��������
//  __LINE__ ��ȡ���д������ļ��е��к�
//  __func__ �� __FUNCTION__ ��ȡ������
#define LOGI(format, ...)  fprintf(stderr,"[INFO] [%s:%d]:%s() " format "\n", __FILE__,__LINE__,__func__,##__VA_ARGS__)
#define LOGE(format, ...)  fprintf(stderr,"[ERROR] [%s:%d]:%s() " format "\n", __FILE__,__LINE__,__func__,##__VA_ARGS__)


int main() {

	const char* ip = "127.0.0.1";
	uint16_t port = 8080;
	LOGI("TcpServer1 tcp://%s:%d", ip, port);

	SOCKET server_fd = -1;
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		LOGI("WSAStartup error");
		return -1;
	}
	SOCKADDR_IN server_addr;

	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	//server_addr.sin_addr.s_addr = inet_addr("192.168.2.61");
	server_addr.sin_port = htons(port);

	server_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (bind(server_fd, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		LOGI("socket bind error");
		return -1;
	}

	if (listen(server_fd, SOMAXCONN) < 0) {
		LOGI("socket listen error");
		return -1;
	}

	while (true)
	{
		LOGI("��������������...");
		// ������������ start
		int len = sizeof(SOCKADDR);
		SOCKADDR_IN accept_addr;
		int clientFd = accept(server_fd, (SOCKADDR*)&accept_addr, &len);
		//const char* clientIp = inet_ntoa(accept_addr.sin_addr);

		if (clientFd == SOCKET_ERROR) {
			LOGI("accept connection error");
			break;
		}
		// ������������ end
		LOGI("���������ӣ�clientFd=%d", clientFd);

		int size;
		uint64_t totalSize = 0;
		time_t  t1 = time(NULL);

		while (true) {
			char buf[1024];
			memset(buf, 1, sizeof(buf));
			size = ::send(clientFd, buf, sizeof(buf), 0);
			if (size < 0) {
				printf("clientFd=%d,send error�������룺%d\n", clientFd, WSAGetLastError());

				break;
			}
			totalSize += size;

			if (totalSize > 62914560)/* 62914560=60*1024*1024=60mb*/
			{
				time_t t2 = time(NULL);
				if (t2 - t1 > 0) {
					uint64_t speed = totalSize / 1024 / 1024 / (t2 - t1);
					printf("clientFd=%d,size=%d,totalSize=%llu,speed=%lluMbps\n", clientFd, size, totalSize, speed);

					totalSize = 0;
					t1 = time(NULL);
				}
			}


		}

		LOGI("�ر����� clientFd=%d", clientFd);
	}

	return 0;
}